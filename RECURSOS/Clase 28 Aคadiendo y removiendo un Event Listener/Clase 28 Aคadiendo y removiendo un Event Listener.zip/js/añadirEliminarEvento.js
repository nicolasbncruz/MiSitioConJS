// addEventListener(); - Añadir un escuchador

var boton = document.getElementById('boton');

function alerta() {
  alert('Hola');
}

boton.addEventListener('click', alerta);




// removeEventListener(); - Eliminar un escuchador

boton.removeEventListener('click', alerta);

// https://developer.mozilla.org/en-US/docs/Web/Events
