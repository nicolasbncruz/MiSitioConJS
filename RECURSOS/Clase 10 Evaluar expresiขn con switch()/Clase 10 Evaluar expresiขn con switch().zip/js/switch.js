var colorFavorito = 'azul';

switch(colorFavorito){
  case 'azul': alert('Tu color favorito es azul');
  break;

  case 'rojo': alert('Tu color favorito es rojo');
  break;

  case 'verde': alert('Tu color favorito es verde');
  break;

  default: alert('No reconocemos tu color favorito');
  break;
}
