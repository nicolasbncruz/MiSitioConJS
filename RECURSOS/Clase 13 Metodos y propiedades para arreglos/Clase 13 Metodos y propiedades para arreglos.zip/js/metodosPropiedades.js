/*
Una propiedad es una característica del objeto mientras que un método es una acción
*/

// object.nombreDelMetodo(); // Esto es un método
// object.nombrePropiedad; // Esto es una propiedad

// Si describésemos a una persona,
// Una propiedad sería : edad
// Un método sería: caminar

// -------------------------------------------

// METODOS Y PROPIEDADES PARA CADENAS DE TEXTO

var texto = 'Esto es un texto';

// length - El número de caracteres
var numeroCaracteres = texto.length;

// toUpperCase() - Transformar todos los caracteres a mayúsculas

var mayus = texto.toUpperCase();

// toLowerCase() - Transformar todos los caracteres a minúsculas

var minus = texto.toLowerCase();

// substring(0,0) - Extraer desde un punto hasta otro de caracteres

var extraido = texto.substring(11,16);

// replace(valor1, valor2) - Reemplazar una cadena de caracteres por otra

var reemplazado = texto.replace('texto','niño');

// indexOf('o') - Buscara el primer caracter que coincida e indicará la posición

var buscandoE = texto.indexOf('e');

// lastIndexOf('o') - Buscara el último caracter que coincida e indicará la posición

var UltimaE = texto.lastIndexOf('e');

// split(' ') - Se convierte la cadena de texto en un arreglo dividiendo los elementos según el separador indicado

var arreglo = texto.split(' ');

// --------------------------------------------------

// METODOS Y PROPIEDADES PARA ARREGLOS

var familia = ['Alejandro', 'Maria', 'Pedro'];
var familiaDos = ['Tomas', 'Saul']

// length  //Devuelve la cantidad de elementos del arreglo

var cantidadElementos = familia.length;

// concat	// Permite unir arreglos

var familiaCompleta = familia.concat(familiaDos);

// join    // Contrario a split - Mostrar todos los elementos del arreglo en una cadena de texto

var textoArreglo = familia.join();

// pop	// Eliminar el último elemento del arreglo

// var familiaIncompleta = familia.pop();

// push	// Agregar un elemento al final del arreglo

// var familiaTres = familia.push('Tomas');

// shift	// Eliminar el primer elemento del arreglo

// familia.shift();

// unshift	// Agregar un elemento al principio del arreglo

// familia.unshift('Tomas');

// reverse	// Ordena el arreglo al revés

// familia.reverse();
