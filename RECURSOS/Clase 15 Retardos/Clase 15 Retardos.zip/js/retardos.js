

// setTimeout(funcion, tiempo en milisegundos);


var texto = 'Hola, soy un texto';

setTimeout(function () {
  alert(texto);
}, 4000)
