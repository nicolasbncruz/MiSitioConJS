
var planta = {
  color: 'Verde',
  tamaño: 'Grande',
  cantidad: 5,
}

document.write(planta.color)
