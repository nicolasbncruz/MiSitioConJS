// SELECTORES INDIVIDUALES
// getElementById(): Selecciona el elemento por su atrubuto ID
// querySelector(): Selecciona el elemento con un selector CSS, devolviéndo el primer elemento que coincida

// SELECTORES MÚLTIPLES
// getElementsByClassName(): Selecciona todos los elementos que tengan la clase especificada
// getElementsByTagName(): Selecciona todos los elementos con la etiqueta especificada
// querySelectorAll(): Selecciona todos los elementos con el selector CSS especificado

// ---------------------------------------------------------------------------------

var parrafo = document.querySelectorAll('.texto');
