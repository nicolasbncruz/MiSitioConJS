$(document).ready(function () {

  // Eliminar elemento incluyendo todos sus elementos hijo
  // $('.contenedor').remove();


  // Eliminar solo los elementos hijo
    // $('.contenedor').empty();
    // $('.contenedor').children().remove()


  // Eliminar un elemento hijo específico
    // $('.contenedor').children('#segundo').remove()

});
