// CONTINUE - Permite saltar a la siguiente ejecución del ciclo

var semana = ['Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado']

for(dia in semana){

  if (semana[dia] == 'Jueves') {
    continue;
  }

  console.log(semana[dia]);




}
