// SINTAXIS

// while(condicion){
//
// }

//

// var i = 1;
//
// while(i < 11){
//
//   document.write(i + '<br>');
//   i++;
//
// }

// Ciclo do while - Ejecuta el código al menos 1 vez

var i = 1;

do {
  document.write(i + '<br>');

  i = i + 1;

}while(i < 11);
