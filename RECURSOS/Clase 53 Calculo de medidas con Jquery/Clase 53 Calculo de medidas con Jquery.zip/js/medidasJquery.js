$(document).ready(function () {

  var boton = $('#boton');

  // Calcular ancho de un elemento

  // boton.on('click', function () {
  //
  //   // var ancho = $('#segundo').width(); // Ancho del elemento
  //   // var ancho = $('#segundo').innerWidth(); // Ancho incluyendo padding
  //   // var ancho = $('#segundo').outerWidth(); // Ancho incluyendo padding y border
  //   // var ancho = $('#segundo').outerWidth(true); // Ancho incluyendo padding, border y margin
  //   alert(ancho);
  //
  // })

  // Calcular el alto de un elemento

  // boton.on('click', function () {

    // var alto = $('#segundo').height(); // Alto del elemento
    // var alto = $('#segundo').innerHeight(); // Alto incluyendo padding
    // var alto = $('#segundo').outerHeight(); // Alto incluyendo padding y border
    // var alto = $('#segundo').outerHeight(true);
    // alert(alto);

  // })

  // https://api.jquery.com/category/css/

  // https://api.jquery.com/category/offset/

});
