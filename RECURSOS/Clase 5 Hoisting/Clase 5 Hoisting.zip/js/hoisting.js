

var numero; //Declaración de la variable


document.write(numero);


numero = 5; //Inicialización de la variable
