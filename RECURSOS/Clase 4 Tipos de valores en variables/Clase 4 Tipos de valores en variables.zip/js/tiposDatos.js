// Tipos de información que se puede almacenar en variables

// NUMERICA
var numero = 5;
var decimal = 0.5;

// CADENA DE TEXTO
var texto = 'Hola, soy una variable';

// BOOLEANA
var booleano = true;
var booleanoDos = false;

// ELEMENTOS HTML
var segundoParrafo = document.querySelector('#texto');


// ARREGLOS
var familia = ['Alejandro', 'Maria', 'Pedro']


// OBJETOS
var planta = {
  color: 'verde',
  tamaño: 'grande',
  cantidad: 3
}


// FUNCIONES
var miFuncion = function(){};
