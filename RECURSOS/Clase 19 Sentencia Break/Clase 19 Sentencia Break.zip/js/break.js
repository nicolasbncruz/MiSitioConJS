// BREAK - Permite detener el ciclo

var semana = ['Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado']

for(dia in semana){
  console.log(semana[dia]);

  if (semana[dia] == 'Miercoles') {
    break;
  }
}
