
var izquierda = document.getElementById('izquierda'),
    spaceAround = document.getElementById('spaceAround'),
    centrado = document.getElementById('centrado'),
    spaceBetween = document.getElementById('spaceBetween'),
    derecha = document.getElementById('derecha'),
    cajas = document.getElementById('cajas');


izquierda.addEventListener('click', function() {
  cajas.style.justifyContent = 'flex-start';
});

spaceAround.addEventListener('click', function() {
  cajas.style.justifyContent = 'space-around';
});

centrado.addEventListener('click', function() {
  cajas.style.justifyContent = 'center';
});

spaceBetween.addEventListener('click', function() {
  cajas.style.justifyContent = 'space-between';
});

derecha.addEventListener('click', function() {
  cajas.style.justifyContent = 'flex-end';
});
