$(document).ready(function(){

  // SELECTORES EN JQUERY

  // Seleccionando una etiqueta
  $('h1');

  // Seleccionando varias etiquetas
  $('h1, p');

  // Seleccionando un ID
  $('#segundo');

  // Seleccionando una clase
  $('.texto');

  $('.contenedor a').hide();



});
