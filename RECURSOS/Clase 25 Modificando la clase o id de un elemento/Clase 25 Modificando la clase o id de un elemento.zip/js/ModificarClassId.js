var primerParrafo = document.getElementsByClassName('texto')[0];

// Modificar clase de un elemento
// primerParrafo.className = 'texto fondo-rojo';


// Modificar Id de un elemento

primerParrafo.id = 'primerParrafo';
