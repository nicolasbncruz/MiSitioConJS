var primerNombre = 'Maria';

alert(primerNombre);
