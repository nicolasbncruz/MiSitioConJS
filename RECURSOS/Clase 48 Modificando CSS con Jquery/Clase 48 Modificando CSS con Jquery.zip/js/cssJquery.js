$(document).ready(function () {

  // Añadir una clase al elemento
  // $('#segundo').addClass('fondo-rojo');

  // Eliminar una clase al elemento
    // $('#segundo').removeClass('texto');

  // Alternar en agregar o eliminar una clase
  // function cambiarFondo() {
  //   $('#segundo').toggleClass('fondo-rojo');
  // }
  //
  // $('#boton').click(cambiarFondo);

  //-----------------------------------------

  // Cambiando una sola propiedad
  // $('#segundo').css('background','blue')

  // Cambiando varias propiedades
  $('#segundo').css({
    background: 'yellow',
    color: 'blue'
  });

});
