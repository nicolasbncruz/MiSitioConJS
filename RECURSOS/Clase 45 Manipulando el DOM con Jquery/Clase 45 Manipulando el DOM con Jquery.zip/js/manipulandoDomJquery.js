$(document).ready(function () {

  // Modificar texto
  // $('#segundo').text(); // Devuelve el texto del elemento
  // $('#segundo').text('Nuevo texto'); // Cambia el texto del elemento

  // Modificar HTML
  // $('#segundo').html('<strong>Esto es un nuevo párrafo en negrita</strong>') // Agregar código HTML o modificar el existente

  // Modificar o agregar atributos
  // $('.texto').eq(0).attr('id', 'primero')
  // $('.texto').eq(0).attr({
  //
  //   id: 'primero',
  //   class: 'texto fondo-rojo'
  //
  // })

});
