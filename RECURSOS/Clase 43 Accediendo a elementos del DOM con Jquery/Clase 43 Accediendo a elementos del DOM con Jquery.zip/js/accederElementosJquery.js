$(document).ready(function(){

// .css('background', '#ccc')



// Seleccionar elemento padre de un elemento
$('#segundo').parent()

// Seleccionar elementos padre de un elemento
$('#segundo').parents()

// Seleccionar elementos hijo de un elemento
$('.contenedor').children()

// Seleccionar elemento hijo específico de un elemento
$('.contenedor').children('#segundo')

// Seleccionar elementos dentro un elemento no necesariamente hijos directos
$('body').find('.texto')

// Seleccionar elementos hermano de un elemento
$('#segundo').siblings()

// Seleccionar elemento anterior a un elemento
$('#segundo').prev()
$('#segundo').prevAll()

// Seleccionar elemento siguiente a un elemento
$('#segundo').next()
$('#segundo').nextAll()

});
