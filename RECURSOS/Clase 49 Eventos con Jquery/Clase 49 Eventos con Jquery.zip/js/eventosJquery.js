$(document).ready(function () {

  // https://api.jquery.com/category/events/

  var boton = $('#boton');
  var segundoBoton = $('#segundoBoton');

  // Añadiendo un evento con función anónima
  // boton.click(function () {
  //
  //   alert('Hola, soy un texto');
  //
  // })

  // Añadiendo un evento con función declarada

  // function saludo() {
  //   alert('Hola, soy un texto');
  // }
  //
  // boton.click(saludo);

  // Añadiendo evento con .on()
  // boton.on('dblclick', function () {
  //
  //   alert('Hola, soy un texto diferente');
  //
  // });
  //
  // // Eliminando evento con .off()
  //
  // segundoBoton.on('click', function () {
  //
  //   boton.off('dblclick');
  //
  // });

});
