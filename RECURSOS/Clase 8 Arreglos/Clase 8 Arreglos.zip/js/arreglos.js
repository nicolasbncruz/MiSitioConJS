// var familia = ['Alejandro', 'Maria', 'Pedro']

// Seleccionar un valor en un arreglo

// document.write(familia[1]);

// -----------------------------------------


var familia = [];

familia[0] = 'Alejandro';
familia[1] = 'Maria';
familia[2] = 'Pedro';
familia[10] = 'Tomas';
