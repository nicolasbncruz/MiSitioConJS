$(document).ready(function () {

  var boton = $('#boton');

  boton.on('click', function () {

    // .animate(Propiedades, tiempo en milisegundos, funcion(callback))

    // $('#segundo').animate({
    //
    //   width: '50%'
    //
    // }, 2000);

    $('#segundo').animate({
      width: '50%'
    }, 2000)

    $('#segundo').animate({
      width: '80%'
    }, 2000)

  })

});
