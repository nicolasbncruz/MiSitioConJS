var rojo = document.getElementById('rojo'),
    blanco = document.getElementById('blanco'),
    azul = document.getElementById('azul'),
    fondoAzul = document.getElementById('fondoAzul'),
    fondoAmarillo = document.getElementById('fondoAmarillo'),
    caja = document.getElementsByClassName('caja');

rojo.addEventListener('click', function() {

  for (var i = 0; i < caja.length; i++) {
    caja[i].style.color = 'red';
  }

});

blanco.addEventListener('click', function() {

  for (var i = 0; i < caja.length; i++) {
    caja[i].style.color = 'white';
  }

});

azul.addEventListener('click', function() {

  for (var i = 0; i < caja.length; i++) {
    caja[i].style.color = 'blue';
  }

});

fondoAzul.addEventListener('click', function() {

  for (var i = 0; i < caja.length; i++) {
    caja[i].style.backgroundColor = 'blue';
  }

});

fondoAmarillo.addEventListener('click', function() {

  for (var i = 0; i < caja.length; i++) {
    caja[i].style.backgroundColor = 'yellow';
  }

});
