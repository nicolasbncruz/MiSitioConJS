/*

if(){}

else if(){}

else{}

*/

var numero = 10;

// if (numero > 2) {
//   alert(numero + ' es mayor que 2');
// } else{
//   alert(numero + ' no es mayor que 2');
// }

// if (numero > 2) {
//   alert(numero + ' es mayor que 2');
// } else if(numero == 2){
//   alert(numero + ' es igual que 2');
// }else{
//   alert(numero + ' no es igual ni mayor que 2');
// }

// OPERADORES
/*
AND    &&
OR     ||
NOT    !
*/

// if (!true) {
//   alert('Se cumple la condición');
// }
