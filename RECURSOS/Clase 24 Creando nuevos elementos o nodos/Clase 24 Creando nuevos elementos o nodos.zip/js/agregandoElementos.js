// Crear nuevo elemento o nodo

// <p class="texto">Hola, soy un texto nuevo</p>
//

var parrafo = document.createElement('p');

var textoNuevo = document.createTextNode('Hola, soy un texto nuevo');

parrafo.appendChild(textoNuevo);

parrafo.setAttribute('class','texto');

var contenedor = document.getElementsByClassName('contenedor')[0];

contenedor.appendChild(parrafo);
