var numero = Math.round(Math.random()*10);

console.log(numero);

// Math.random(); // Obtener números aleatorios

// Math.floor(Math.random()*10) // Redondear al número entero menor

// Math.ceil(Math.random()*10) // Redondear al número entero mayor

// Math.round(Math.random()*10) // Redondear al número entero más cercano
