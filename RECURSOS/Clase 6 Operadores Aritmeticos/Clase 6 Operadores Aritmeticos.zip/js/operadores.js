// LOS OPERADORES

// ----------------------------------

// OPERADORES ARITMÉTICOS

var primerNumero = 21;
var segundoNumero = 4;

// + Suma
// var suma = primerNumero + segundoNumero;

// - Resta
// var resta = primerNumero - segundoNumero;

// * Multiplicación
// var multiplicacion = primerNumero * segundoNumero;

// / División
// var division = primerNumero / segundoNumero;

// % Modulo
// var modulo = primerNumero % segundoNumero;

// ++ Incrementar
// var incrementado = ++primerNumero;

// -- Decrementar
// var decrementado = --primerNumero;

// -----------------------------------


// OPERADORES DE ASIGNACIÓN

var tercerNumero;

// = Asignar un valor

// += Asignar un valor sumándolo con su anterior

// -= Asignar un valor restándolo con su anterior

// *= Asignar un valor multiplicándolo con su anterior

// /= Asignar un valor dividiéndolo con su anterior


// -----------------------------------


// OPERADORES DE CADENAS DE TEXTO

var primerTexto = 'Soy un texto y'
var segundoTexto = 'yo soy otro'

// + Concatenar


// -----------------------------------

// OPERADORES LÓGICOS

var CuartoNumero = 10;
var QuintoNumero = 10;

// == Igual a

// === Igual valor y tipo

// != No es igual (Diferente)

// !== Diferente en valor y tipo

// > mayor que

// < menor que

// >= mayor o igual que

// <= menor o igual que
