$(document).ready(function () {

  $('.texto').on('click', function () {

    $(this).toggleClass('fondo-rojo');

  })

});
