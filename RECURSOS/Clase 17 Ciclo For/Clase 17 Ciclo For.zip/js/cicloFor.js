/*
CICLO FOR

En esta clase aprenderemos a crear un ciclo for, que se hace para crear
un bucle, es decir, una o varias acciones que se repitan una y otra vez.
*/

// Sintaxis:

// for(variable inicio; longitud o condicion; incremento){

  //Información a repetir

// };

// for(var i = 0; i < 10; i++){
//
//   document.write(i);
//
// }

// var semana = ['Domingo','Lunes','Martes','Miercoles','Jueves', 'Viernes', 'Sabado']
//
// for(var i = 0; i < semana.length; i++){
//
//   document.write(semana[i] + '<br>')
//
// }

// -----------------------------------------------------------------------

// For in

var semana = ['Domingo','Lunes','Martes','Miercoles','Jueves', 'Viernes', 'Sabado']

for(dia in semana){

  document.write(semana[dia] + '<br>')

}
