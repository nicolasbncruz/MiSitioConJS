

// setInterval(funcion, tiempo en milisegundos);


var segundos = 0;

setInterval(function () {

  document.write(segundos++);

}, 1000);
