$(document).ready(function () {

  var contenedor = $('.contenedor');
  var segundoParrafo = $('#segundo');

  $('#boton').click(function () {

    var nuevoParrafo = $('<p>').attr('class', 'texto').text('Esto es un nuevo párrafo');

    // contenedor.append(nuevoParrafo); // Agregar elemento al final

    // contenedor.prepend(nuevoParrafo); // Agregar elemento al inicio

    // segundoParrafo.before(nuevoParrafo); // Agregar elemento antes del seleccionado

    // segundoParrafo.after(nuevoParrafo); // Agregar elemento después del seleccionado

  })

});
