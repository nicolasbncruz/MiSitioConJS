$(document).ready(function () {

  // Escribimos todo nuestro código

});
