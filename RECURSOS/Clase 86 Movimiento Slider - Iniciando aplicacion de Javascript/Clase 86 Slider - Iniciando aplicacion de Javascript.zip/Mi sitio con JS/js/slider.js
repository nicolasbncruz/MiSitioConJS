$(document).ready(function () {

  // Seleccionando elementos en variables
  var slider = $('#slider');
  var btnAnterior = $('#btnAnterior');
  var btnSiguiente = $('#btnSiguiente');

  // Se pasa el último slide al primer lugar
  $('#slider .slide:last').insertBefore('#slider .slide:first');

  // Con margen negativo se vuelve a mostrar el primer slide
  slider.css('margin-left', '-43%');

});
