var grande = document.getElementById('grande'),
    medio = document.getElementById('medio'),
    pequeño = document.getElementById('pequeño'),
    mayus = document.getElementById('mayus'),
    minus = document.getElementById('minus'),
    caja = document.getElementsByClassName('caja');

grande.addEventListener('click', function() {

  for(var i = 0; i < caja.length; i++){

    caja[i].style.fontSize = '30px';

  }

});

medio.addEventListener('click', function() {

  for(var i = 0; i < caja.length; i++){

    caja[i].style.fontSize = '16px';

  }

});

pequeño.addEventListener('click', function() {

  for(var i = 0; i < caja.length; i++){

    caja[i].style.fontSize = '12px';

  }

});

mayus.addEventListener('click', function() {

  for(var i = 0; i < caja.length; i++){

    caja[i].style.textTransform = 'uppercase';

  }

});

minus.addEventListener('click', function() {

  for(var i = 0; i < caja.length; i++){

    caja[i].style.textTransform = 'lowercase';

  }

});
