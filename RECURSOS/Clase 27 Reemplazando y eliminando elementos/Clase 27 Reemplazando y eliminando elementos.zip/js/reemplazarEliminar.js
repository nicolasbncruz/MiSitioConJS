var parrafos = document.getElementsByClassName('texto');

// Elemento padre
var padreParrafos = parrafos[0].parentNode;

// Creando nuevo párrafo
var parrafo = document.createElement('p');

var textoNuevo = document.createTextNode('Hola, soy un texto nuevo');

parrafo.appendChild(textoNuevo);

parrafo.setAttribute('class','texto');

var contenedor = document.getElementsByClassName('contenedor')[0];

//-----------------------------------------------------------------


// Reemplazando un elemento
// padreParrafos.replaceChild(parrafo, parrafos[2]);

// Eliminando un elemento
padreParrafos.removeChild(parrafos[0]);
