// DECLARAR LA FUNCIÓN

// var numero1 = 5;
// var numero2 = 5;

// function sumar(){
//   var resultado = numero1+numero2;
//   if (resultado >= 12) {
//     alert(resultado);
//   } else{
//     document.write(resultado);
//   }
// }

// EJECUTAR LA FUNCIÓN

// sumar();


// ----------------------------------

// DECLARAR LA FUNCIÓN

function sumar(valor1,valor2){

  var resultado = valor1+valor2;

  if (resultado >= 12) {

    alert(resultado);

  } else{

    document.write(resultado);

  }
}

// EJECUTAR LA FUNCIÓN

sumar(5,3);
