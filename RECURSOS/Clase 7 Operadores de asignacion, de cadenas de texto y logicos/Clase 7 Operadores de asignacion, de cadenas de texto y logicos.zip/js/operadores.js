// LOS OPERADORES

// ----------------------------------

// OPERADORES ARITMÉTICOS

var primerNumero = 21;
var segundoNumero = 4;

// + Suma
// var suma = primerNumero + segundoNumero;

// - Resta
// var resta = primerNumero - segundoNumero;

// * Multiplicación
// var multiplicacion = primerNumero * segundoNumero;

// / División
// var division = primerNumero / segundoNumero;

// % Modulo
// var modulo = primerNumero % segundoNumero;

// ++ Incrementar
// var incrementado = ++primerNumero;

// -- Decrementar
// var decrementado = --primerNumero;

// -----------------------------------


// OPERADORES DE ASIGNACIÓN

var tercerNumero;

// = Asignar un valor

tercerNumero = 10;

// += Asignar un valor sumándolo con su anterior

// -= Asignar un valor restándolo con su anterior

// *= Asignar un valor multiplicándolo con su anterior

// /= Asignar un valor dividiéndolo con su anterior


// -----------------------------------


// OPERADORES DE CADENAS DE TEXTO

var primerTexto = 'Soy un texto y '
var segundoTexto = 'yo soy otro'

// + Concatenar

var textoJunto = primerTexto + segundoTexto;
// document.write(textoJunto);


// -----------------------------------

// OPERADORES LÓGICOS

var CuartoNumero = 10;
var QuintoNumero = 5;

// == Igual a

// var resultadoLogico = CuartoNumero == QuintoNumero;
// document.write(resultadoLogico);

// === Igual valor y tipo

// var resultadoLogico = CuartoNumero === QuintoNumero;
// document.write(resultadoLogico);

// != No es igual (Diferente)

// var resultadoLogico = CuartoNumero != QuintoNumero;
// document.write(resultadoLogico);

// !== Diferente en valor y/o tipo

// var resultadoLogico = CuartoNumero !== QuintoNumero;
// document.write(resultadoLogico);

// > mayor que

// var resultadoLogico = CuartoNumero > QuintoNumero;
// document.write(resultadoLogico);

// < menor que

// var resultadoLogico = CuartoNumero < QuintoNumero;
// document.write(resultadoLogico);

// >= mayor o igual que

// var resultadoLogico = CuartoNumero >= QuintoNumero;
// document.write(resultadoLogico);

// <= menor o igual que

// var resultadoLogico = CuartoNumero <= QuintoNumero;
// document.write(resultadoLogico);
