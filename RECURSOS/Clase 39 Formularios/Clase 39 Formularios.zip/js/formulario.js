
var form = document.getElementById('formulario');
var nombre = document.getElementById('nombre');
var email = document.getElementById('email');
var verde = document.getElementById('verde');
var amarillo = document.getElementById('amarillo');
var azul = document.getElementById('azul');
var terminos = document.getElementById('terminos');


// Acceder a los input por name
// form.nombre;


// Validando un formulario

function validar(e){

  if (nombre.value == '') {
    alert('Por favor escribe tu nombre');
    e.preventDefault();
  }

  if (email.value == '') {
    alert('Por favor escribe tu email');
    e.preventDefault();
  }

  if (verde.checked == false && amarillo.checked == false && azul.checked == false) {
    alert('Por favor selecciona tu color favorito');
    e.preventDefault();
  }

  if (terminos.checked == false) {
    alert('Por favor acepta los terminos y condiciones');
    e.preventDefault();
  }

}

form.addEventListener('submit', validar);
