$(document).ready(function () {

  // http://api.jquery.com/category/effects/

  function miEfecto(){

    //  Ocultar elemento
    // $('#segundo').hide()

    // Mostrar elemento
    // $('#segundo').show()

    //  Alternar entre ocultar y mostrar
    // $('#segundo').toggle(2000);

// ---------------------------------------

//  Efecto fadeOut
    // $('#segundo').fadeOut(1000);

//  Efecto fadeIn
// $('#segundo').fadeIn(1000);

//  Alternar entre fadeIn y fadeOut
  // $('#segundo').fadeToggle(1000);

// ---------------------------------------

//  Efecto slideUp
    // $('#segundo').slideUp(2000);

//  Efecto slideDown
    // $('#segundo').slideDown(2000);

//  Alternar entre slideUp y slideDown
      // $('#segundo').slideToggle(2000);

  }

  var boton = $('#boton');
  boton.click(miEfecto);

});
