$(document).ready(function () {

  var boton = $('#boton');
  var detener = $('#detener');

  boton.on('click', function () {

    $('#segundo').animate({
      width: '200%'
    }, 5000)

    $('#segundo').animate({
      width: '300%'
    }, 5000)

    $('#segundo').animate({
      width: '100%'
    }, 5000)

  })

  detener.on('click', function () {

    // .stop(limpiarCola, saltarFinal)

    $('#segundo').stop(false, true)

  })

});
